package com.application.Service;

import java.util.Optional;



import com.application.Entity.UserDetails;

public interface UserInfoService {

	Iterable<UserDetails> findAll();

	Optional<UserDetails> findById(Long id);

	void deleteById(Long id);

	UserDetails findByEmail(String email);

	UserDetails save(UserDetails userinfo);
}
