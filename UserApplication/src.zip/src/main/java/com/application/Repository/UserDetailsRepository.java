package com.application.Repository;

import org.springframework.data.repository.CrudRepository;



import com.application.Entity.UserDetails;

public interface UserDetailsRepository extends CrudRepository<UserDetails, Long> {

	UserDetails findByEmail(String email);

}
