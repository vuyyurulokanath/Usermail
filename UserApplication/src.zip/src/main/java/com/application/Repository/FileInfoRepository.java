package com.application.Repository;

import java.util.List;


import org.springframework.data.repository.CrudRepository;


import com.application.Entity.FileInfo;
import com.application.Enum.Status;

public interface FileInfoRepository extends CrudRepository<FileInfo, Long> {

	List<FileInfo> findByuserid(long userid);

	List<FileInfo> findByuseridAndStatus(long userid, Status status);

	FileInfo findByfilename(String filename);
}
