package com.application.Enum;

public enum Role {
USER,ADMIN
}
