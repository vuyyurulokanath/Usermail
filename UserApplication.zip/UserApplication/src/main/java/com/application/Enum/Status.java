package com.application.Enum;

public enum Status {
	ACTIVE,INACTIVE

}
